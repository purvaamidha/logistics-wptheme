(function ($) {
  "use strict";
  $( document ).ready( function(){
    $('#new-review').autosize({append: "\n"});

    var reviewBox = $('#post-review-box');
    var newReview = $('#new-review');
    var openReviewBtn = $('#open-review-box');
    var closeReviewBtn = $('#close-review-box');
    var ratingsField = $('#ratings-hidden');

    openReviewBtn.click(function(e)
    {
      reviewBox.slideDown(400, function()
        {
          $('#new-review').trigger('autosize.resize');
          newReview.focus();
        });
      openReviewBtn.fadeOut(100);
      closeReviewBtn.show();
    });

    closeReviewBtn.click(function(e)
    {
      e.preventDefault();
      reviewBox.slideUp(300, function()
        {
          newReview.focus();
          openReviewBtn.fadeIn(200);
        });
      closeReviewBtn.hide();
      
    });
  }); // end $( document ).ready
} )( jQuery );